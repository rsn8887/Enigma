TileSize = 16
SpriteSize = 20
ShadowSize = 21
DefineFont ("timefont", "DejaVuSansCondensed.ttf", 18, "timefont", 180, 180, 180)
DefineFont ("smallalternative", "DejaVuSansCondensed.ttf", 7, "menufont")
DefineFont ("modesfont", "DejaVuSansCondensed.ttf", 9, "menufont", 70, 120, 255)
DefineFont ("menufont", "DejaVuSansCondensed.ttf", 9, "menufont")
DefineFont ("levelmenu", "DejaVuSansCondensed.ttf", 9, "levelmenu")
DefineFont ("menufontsel", "DejaVuSansCondensed.ttf", 10, "menufont", 180, 180, 180)
DefineFont ("statusbarfont", "DejaVuSansCondensed.ttf", 7, "dreamorp24")

dofile(FindDataFile("models-2d.lua"))
