enigma.ElectricForce = 60
