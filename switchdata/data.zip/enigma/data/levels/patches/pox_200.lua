enigma.KillStone(14,3)
set_item("it-dynamite",14,3)
