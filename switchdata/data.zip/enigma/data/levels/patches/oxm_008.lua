display.SetFollowMode (display.FOLLOW_SCREENSCROLLING)
