enigma.KillStone(5,18)
set_item("it-dynamite",5,18)
