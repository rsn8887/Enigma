-- Remove rightmost magic stone (cannot be reached by marble)
enigma.KillStone (34,7)
