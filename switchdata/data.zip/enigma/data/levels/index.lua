-- Obsolete index.lua

-- Do not add index.txt entries!
-- This file is just kept for compatibility reasons and to convert user
-- levelpacks. It is subject to be delete in a future release!

-- add test level pack (usually containing levels created by the user)
enigma.AddLevelPack( "levels/index_user.txt", "User Levels")
enigma.AddLevelPack( "levels/+index_user.txt", "Arch friendly User Levels")
