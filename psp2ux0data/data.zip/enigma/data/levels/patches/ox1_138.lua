if enigma.SingleComputerGame then
    kill_item (9,4)
    kill_item (9, 15)

    set_stone ("st-grate1", 9, 4)
    set_stone ("st-grate1", 9, 15)
end
