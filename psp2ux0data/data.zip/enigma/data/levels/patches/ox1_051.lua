enigma.SlopeForce = 40
