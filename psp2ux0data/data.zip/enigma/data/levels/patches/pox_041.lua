enigma.KillStone(52,14)
set_item("it-dynamite",52,14)
