set_item("it-document", 3, 3, 
         {text="Don't despair! There's a hammer hidden near the lower-left knight!"})
